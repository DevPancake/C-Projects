#include <iostream>

int main() {
    int favorite_Number;
    std::cout <<"Enter your favorite number between 1 and 100: ";
    std::cin >> favorite_Number;
    std::cout << "Amazing, that's my favorite number too!" << std::endl;

    system("pause");
    return 0;
}