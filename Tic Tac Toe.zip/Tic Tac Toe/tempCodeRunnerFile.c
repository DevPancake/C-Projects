printf("\nEnter a number above 0: ");
        scanf("%d", &number);
        if(number > 0){
            sum += number;
        }